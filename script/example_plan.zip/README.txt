1-depth 디렉토리로 place 정보 (ex. 고려대박물관, 고려대투어)
각 디렉토리는 (1 + 2 * path종류)개의 파일로 구성
작품.xlsx
각 루트 x들에 대해
 - 추천루트{x}.png (1-zero padding)
    추천루트{x}.xlsx (1-zero padding)
를 작성해주시면 됩니다.

작품.xlsx:
    - ID: 0부터 세주시면 됩니다.
    - name: 작품 이름
    - summary: 최대 300글자
    - description: 최대 30000글자

추천루트{x}.png: 추천루트가 그려진 이미지 필요 (핀은 그리면 안됨)
추천루트{x}.xlsx:
    - ID: 작품.xlsx의 ID
    - x: x 좌표
    - y: y 좌표